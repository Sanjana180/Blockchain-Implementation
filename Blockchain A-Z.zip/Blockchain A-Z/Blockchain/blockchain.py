# create blockchain

#importing the libraries
# for noting the time the block was created/mined.
import datetime
# for using SHA256 - hashing
import hashlib
# to use the dumps() function to encode before hashing
import json
# web framework
from flask import Flask, jsonify


#Part 1- building Blockchain (class approach instead of functions)
class Blockchain:
    #constructor and self is the obj created
    def __init__(self):
        self.chain = []
        # create block funtion called
        self.create_block(proof=1, previous_hash='0')
    
    # self to use the variables of the object
    def create_block(self, proof, previous_hash):
        block = {'index': len(self.chain)+1,
                 'timestamp': str(datetime.datetime.now()),
                 'proof': proof,
                 'previous_hash':previous_hash
                 }
        self.chain.append(block)
        return block
    
    def get_previous_block(self):
        # -1 to get the last block in chain
        return self.chain[-1]
        
    # create a problem that miners will have to solve
    # in this problem the minners will have to consider the previous_proof
    def proof_of_work(self, previous_proof):
        # solving the proof by trial and error, incrementing new_proof
        new_proof = 1
        check_proof = False
        while check_proof is False:
            # making new_proof - previous_proof asymmetrical because
            # at some point if new_proof + previous_proof new will become prev
            # encode() - b'5' byte literals just for formating purpose
            hash_operation = hashlib.sha256(str(new_proof**2 - previous_proof**2).encode()).hexdigest()
            if hash_operation[:4] == '0000':
                check_proof = True
            else :
                new_proof += 1
        return new_proof
    
    def hash(self, block):
        # sort_keys so that our block is sorted by the keys
        encoded_block = json.dumps(block, sort_keys=True).encode()
        return hashlib.sha256(encoded_block).hexdigest()
    
    def is_chain_valid(self, chain):
        previous_block = chain[0]
        block_index = 1
        while block_index < len(chain):
            block = chain[block_index]
            if block['previous_hash'] != self.hash(previous_block):
                return False
            previous_proof = previous_block['proof']
            proof = block['proof']
            hash_operation = hashlib.sha256(str(proof**2 - previous_proof**2).encode()).hexdigest()
            if hash_operation[:4] != '0000':
                return False
            previous_block = block
            block_index += 1
        return True
            
#Part 2- Mining and Blockchain

# Creating a Web App (Flask - for postman)
app = Flask(__name__)

# Creating a Blockchain
blockchain = Blockchain()

# Mining a new block
@app.route('/mine_block', methods=['GET'])
def mine_block():
    previous_block = blockchain.get_previous_block()
    previous_proof = previous_block['proof']
    proof = blockchain.proof_of_work(previous_proof)
    previous_hash = blockchain.hash(previous_block)
    block = blockchain.create_block(proof, previous_hash)
    response = {'message': 'Congratulations, you have just mined a block!',
                'index' : block['index'],
                'timestamp' : block['timestamp'],
                'previous hash' : block['previous_hash'],
                'proof' : block['proof']
                }
    return jsonify(response), 200

# Getting the full Blockchain
@app.route('/get_chain', methods=['GET'])
def get_chain():
    response = {'chain': blockchain.chain,
                'Length of the chain' : len(blockchain.chain)
                }
    return jsonify(response), 200

@app.route('/check_validity', methods=['GET'])
def check_validity():
    check = blockchain.is_chain_valid(blockchain.chain)
    if check:
        response = {'message':'Blockchain is good to go.'}
    else:
        response = {'message':'Houston we have a problem.'}
    return jsonify(response), 200

# Running the app
app.run(host='0.0.0.0', port = 5000)
    




