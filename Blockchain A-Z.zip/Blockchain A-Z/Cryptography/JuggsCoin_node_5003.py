# create cryptocurrency

# need the requests=2.18.4 library. pip install requests==2.18.4
#importing the libraries
# for noting the time the block was created/mined.
import datetime
# for using SHA256 - hashing
import hashlib
# to use the dumps() function to encode before hashing
import json
# web framework (request)
from flask import Flask, jsonify, request
# to catch the right nodes
import requests
from uuid import uuid4
# to parse through the url
from urllib.parse import urlparse


#Part 1- building Blockchain (class approach instead of functions) - converting into a cryptocurrency
class Blockchain:
    #constructor and self is the obj created
    def __init__(self):
        self.chain = []
        self.transactions = []
        # create block funtion called
        self.create_block(proof=1, previous_hash='0')
        # Distributive P2P network
        self.nodes = set()
    
    # self to use the variables of the object
    def create_block(self, proof, previous_hash):
        block = {'index': len(self.chain)+1,
                 'timestamp': str(datetime.datetime.now()),
                 'proof': proof,
                 'previous_hash':previous_hash,
                 'transactions':self.transactions
                 }
        # after transactions are added empty the list
        self.transactions = []
        self.chain.append(block)
        return block
    
    def get_previous_block(self):
        # -1 to get the last block in chain
        return self.chain[-1]
        
    # create a problem that miners will have to solve
    # in this problem the minners will have to consider the previous_proof
    def proof_of_work(self, previous_proof):
        # solving the proof by trial and error, incrementing new_proof
        new_proof = 1
        check_proof = False
        while check_proof is False:
            # making new_proof - previous_proof asymmetrical because
            # at some point if new_proof + previous_proof new will become prev
            # encode() - b'5' byte literals just for formating purpose
            hash_operation = hashlib.sha256(str(new_proof**2 - previous_proof**2).encode()).hexdigest()
            if hash_operation[:4] == '0000':
                check_proof = True
            else :
                new_proof += 1
        return new_proof
    
    def hash(self, block):
        # sort_keys so that our block is sorted by the keys
        encoded_block = json.dumps(block, sort_keys=True).encode()
        return hashlib.sha256(encoded_block).hexdigest()
    
    def is_chain_valid(self, chain):
        previous_block = chain[0]
        block_index = 1
        while block_index < len(chain):
            block = chain[block_index]
            if block['previous_hash'] != self.hash(previous_block):
                return False
            previous_proof = previous_block['proof']
            proof = block['proof']
            hash_operation = hashlib.sha256(str(proof**2 - previous_proof**2).encode()).hexdigest()
            if hash_operation[:4] != '0000':
                return False
            previous_block = block
            block_index += 1
        return True
    
    # adding new transactions to the list and returning the block no. in which this will be added
    def add_transactions(self, sender, receiver, amount):
        self.transactions.append({'sender':sender,
                                  'receiver':receiver,
                                  'amount': amount
                                  })
        previous_block = self.get_previous_block()
        return previous_block['index']+1
    
    def add_node(self, address):
        # for spliting the url into components
        parsed_url = urlparse(address)
        # netloc is the ip address
        self.nodes.add(parsed_url.netloc)
        
    # consensus 
    def replace_chain(self):
        network = self.nodes
        longest_chain = None
        max_length = len(self.chain)
        # requests used here
        for nodes in network:
            response = requests.get(f'http://{nodes}/get_chain')
            if response.status_code == 200:
                length = response.json()['Length of the chain']
                chain = response.json()['chain']
                if length > max_length and self.is_chain_valid(chain):
                    max_length = length
                    longest_chain = chain
        if longest_chain:
            self.chain = longest_chain
            return True
        return False
    
    
            
#Part 2- Mining and Blockchain

# Creating a Web App (Flask - for postman)
app = Flask(__name__)

# creating an address for node on Port 5000
# uuid will be used to generate random address
# first transaction done when a user mines a block, from node to miner
# this address is for port 5000
node_address = str(uuid4()).replace('-','')

# Creating a Blockchain
blockchain = Blockchain()

# Mining a new block
@app.route('/mine_block', methods=['GET'])
def mine_block():
    previous_block = blockchain.get_previous_block()
    previous_proof = previous_block['proof']
    proof = blockchain.proof_of_work(previous_proof)
    previous_hash = blockchain.hash(previous_block)
    blockchain.add_transactions(sender = node_address, receiver = 'Vivian', amount=1)
    block = blockchain.create_block(proof, previous_hash)
    response = {'message': 'Congratulations, you have just mined a block!',
                'index' : block['index'],
                'timestamp' : block['timestamp'],
                'previous hash' : block['previous_hash'],
                'proof' : block['proof'],
                'transactions':block['transactions']
                }
    return jsonify(response), 200

# Getting the full Blockchain
@app.route('/get_chain', methods=['GET'])
def get_chain():
    response = {'chain': blockchain.chain,
                'Length of the chain' : len(blockchain.chain)
                }
    return jsonify(response), 200

@app.route('/check_validity', methods=['GET'])
def check_validity():
    check = blockchain.is_chain_valid(blockchain.chain)
    if check:
        response = {'message':'Blockchain is good to go.'}
    else:
        response = {'message':'Houston we have a problem.'}
    return jsonify(response), 200

# adding new transaction to the blockchain
@app.route('/add_transaction', methods=['POST'])
def add_transaction():
    # get json from postman
    json = request.get_json()
    transaction_keys = ['sender','receiver','amount']
    if not all (key in json for key in transaction_keys):
        return 'some elements of the transaction are missing', 400
    index = blockchain.add_transactions(json['sender'], json['receiver'], json['amount'])
    response = {'message': f'Transaction will be added to Block {index}'}
    return jsonify(response), 201
    
#Part 3 - decentralizing our Blockchain

# connect new nodes
@app.route('/connect_node', methods=['POST'])
def connect_node():
    json = request.get_json()
    nodes = json.get('nodes')
    if nodes is None:
        return 'No node found', 400
    for node in nodes:
        blockchain.add_node(node)
    response = {'message': 'All the nodes are now connected. The JuggsCoin Blockchain now contains the following nodes : ',
                'total_nodes': list(blockchain.nodes)}
    return jsonify(response), 201

# replacing the chain by the longest chain if needed
@app.route('/replace_chain', methods=['GET'])
def replace_chain():
    check = blockchain.replace_chain()
    if check:
        response = {'message':'Blockchain is updated',
                    'new _chain': blockchain.chain}
    else:
        response = {'message':'Great! The chain is up to date',
                    'actual_chain': blockchain.chain}
    return jsonify(response), 200

# Running the app
app.run(host='0.0.0.0', port = 5003)


    




